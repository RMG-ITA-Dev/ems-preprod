### 1.3.0

- [add] precise string id handling

### 1.2.2

- [add] useHotkeys hook

### 1.1.1

- [dev] exclude `react` from the lib output

### 1.1.0

- [add] useStore, useWritableProp hooks
- [add] delegateClick helper
- [add] writable implementation
