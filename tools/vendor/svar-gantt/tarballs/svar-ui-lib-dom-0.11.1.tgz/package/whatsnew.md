### 0.11.1

- [fix] export TPosition type

### 0.11.0

- [add] more precise positioning options to align elements relative to parent
- [fix] incorrect positioning close to container edges

### 0.10.0

- [add] formatting of quarters
- [add] formatting of weeks using locale
- [add] hotkeys helper to store and exec key handlers

### 0.9.2

- [update] toolchain changed to tsup

### 0.9.1

- [update] getAbsParent returns null for detached nodes

### 0.9.0

- [add] salesforce env

### 0.8.0

- [update] calculatePosition returns null when element is not in DOM
- [fix] auto-fit logic of calculatePosition: actual width is returned, shift to left is done relative to the container not to the original menu position

### 0.7.0

- [add] env, setEnv

### 0.6.0

- [add] calculatePosition, getAbsParent helpers

### 0.5.3

- [add] ability to define modal mode for click-outside

### 0.5.2

- [fix] regression in closing popup on click that activates another popup

### 0.5.1

- [update] clickOutside helper can work with layered content
