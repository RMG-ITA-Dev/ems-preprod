# @svar-ui/lib-react

@svar-ui/lib-react is a library that provides helpers for React integration

![NPM package](https://img.shields.io/npm/v/@svar-ui/lib-react)

## Running Tests

```sh
npx playwright install chromium
npm run test:run
```
